open module Assign5 {
    requires tester;
}