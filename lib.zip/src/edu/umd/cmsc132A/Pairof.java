package edu.umd.cmsc132A;

class Pairof<X, Y> {
    X left;
    Y right;

    Pairof(X left, Y right) {
        this.left = left;
        this.right = right;
    }
}
